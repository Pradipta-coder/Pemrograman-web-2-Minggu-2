<?php

$angka1 = $_POST['angka1'];
$angka2 = $_POST['angka2'];
$jumlah = $_POST['jumlah'];

if ($jumlah == "tambah")
{
$hasil = $angka1+$angka2;
}
if ($jumlah == "kurang")
{
$hasil = $angka1-$angka2;
}
if ($jumlah == "kali")
{
$hasil = $angka1*$angka2;
}
if ($jumlah == "bagi")
{
$hasil = $angka1/$angka2;
}

header ("location:form.php?hasil=$hasil");
?>