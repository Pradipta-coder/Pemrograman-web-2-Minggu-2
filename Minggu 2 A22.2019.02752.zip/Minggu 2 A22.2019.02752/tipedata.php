<html>
    <head>
		<title>
			<?php
				echo "Tipedata PHP";
				?>
		</title>
	</head>
	<body>
		<?php
			$nim  	= "A22.2019.02752";
			$nama 	= 'Dipta';
			$umur 	= 19;
			$nilai 	= 82.25;
			$status = TRUE;
			echo  "NIM 	: " .$nim. "<br>";
			echo  "Nama : $nama<br>";
			print "Umur : " .$umur; print "<br>";
			printf ("Nilai : %.3f<br>", $nilai);
			if ($status)
			echo "Status : Aktif";
			else
			echo "Status : Tidak Aktif";
		?>
</html>		