<html>
    <head>
		<title>
			<?php
				echo "Operator PHP";
				?>
		</title>
	</head>
	<body>
		<?php
			/* Komentar tidak akan tercetak di layar
			Komentar baris kedua
			*/
			// komentar satu baris
			# komentar satu baris
			echo "Muncul dilayar...";
		?>
</html>		