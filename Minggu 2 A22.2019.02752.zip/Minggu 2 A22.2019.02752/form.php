<html>
    <head>
		<title>
			<?php
				echo "Kalkulator PHP";
				?>
		</title>
	</head>
	<body>
	<h2>Kalkulator Serdahana</h2>
	<form action="hitung.php" method="post">
	<label>Bilangan 1</label><input name="angka1" type="text"><br>
	<label>Bilangan 2</label><input name="angka2" type="text"><br>
	<select name="jumlah">
	<option value="tambah" >+</option>
	<option value="kurang" >-</option>
	<option value="bagi" >:</option>
	<option value="kali" >*</option>
	</select>
	<input type="submit" value="Hitung"><br>
	<input name="hasil" type="text" disabled value="<?php if (isset($_GET['hasil'])) echo $_GET['hasil']?>"/>
</html>