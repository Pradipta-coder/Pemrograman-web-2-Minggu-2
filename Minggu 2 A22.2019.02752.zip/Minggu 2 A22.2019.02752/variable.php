<html>
    <head>
		<title>
			<?php
				echo "Variabel PHP";
				?>
		</title>
	</head>
	<body>
		<?php
			$nim 		= "A22.2019.02752";
			$nama	= 'Dipta';
			echo "NIM  : ".$nim. "<br>";
			echo "Nama : $nama";
		?>
</html>		