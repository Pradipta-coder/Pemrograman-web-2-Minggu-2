<html>
    <head>
		<title>
			<?php
				echo "Konstanta PHP";
				?>
		</title>
	</head>
	<body>
			<?php
			define ("NAMA", "Dipta ");
			define ("NILAI", 90);
			echo "Nama : " .NAMA;
			echo "<br>Nilai : " .NILAI;
			?>
</html>			