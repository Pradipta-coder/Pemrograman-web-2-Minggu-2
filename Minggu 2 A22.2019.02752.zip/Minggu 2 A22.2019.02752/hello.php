<html>
    <head>
		<title>
			<?php
				echo "Belajar PHP";
				?>
		</title>
	</head>
	<body>
		<?php
		$a=1;
		$b=2;
		$c=$a+$b;
		// ini script PHP pertama saya
		echo "Nilai a = ".$a;
		echo "<br>Nilai b = ".$b;
		echo "<br>a+b = ".$c;
		echo "<br>Hello World..";
		?>
	</body>
</html>	